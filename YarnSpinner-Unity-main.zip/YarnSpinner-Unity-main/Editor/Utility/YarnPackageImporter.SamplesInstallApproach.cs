namespace Yarn.Unity.Editor
{
    public static partial class YarnPackageImporter
    {
        // what install approach do we follow?
        private static InstallApproach installApproach = InstallApproach.Manual;

    }
}
