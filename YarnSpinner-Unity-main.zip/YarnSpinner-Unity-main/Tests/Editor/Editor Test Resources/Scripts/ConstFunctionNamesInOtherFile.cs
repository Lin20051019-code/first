namespace Yarn.Unity
{
    public static class ConstFunctionNamesInOtherFile
    {
        public const string DirectRegisterExternalFileFunctionNameLambda = "direct_register_external_file_function_lambda";
        public const string DirectRegisterExternalFileFunctionNameMethod = "direct_register_external_file_function_method";
        public const string StaticExternalFileFunctionName = "external_file_function";
        public const string StaticExternalFileCommandName = "external_file_command";
    }
}
