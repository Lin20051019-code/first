﻿/*
Yarn Spinner is licensed to you under the terms found in the file LICENSE.md.
*/

using System.Reflection;
using System.Runtime.CompilerServices;

[assembly: AssemblyVersion("3.0.3.0")]
[assembly: AssemblyFileVersion("3.0.3.0")]
[assembly: AssemblyInformationalVersion("3.0.3.Branch.main.Sha.a906ced7bf2221568debb0626f8eee51b6a98b4c")]
[assembly: InternalsVisibleTo("YarnSpinnerTests")]
[assembly: InternalsVisibleTo("YarnSpinner.Editor.Tests")]
[assembly: InternalsVisibleTo("YarnSpinner.Unity.Editor")]

